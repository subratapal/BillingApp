var login = require('../models/databasemodel');

module.exports = function(app) {

    app.get('/api/setuplogin1234' ,function(req,res){
        //seed first data
        var storeperson = {
            username : 'Subrata',
            password : '1234'
        }

        login.login.create(storeperson,function(err,result){
            res.send('Success');
        });
    });


app.get('/api/seedstock' , function(req,res){

var stock = [{
    Productcode : '796542',
    ProductName : 'DOLO- 650',
    strght : '650mg',
    BatchNo : '65446',
    Expdt : 2017-06-01,
    Mfg : 'MICRO LABS',
    pkg : 'Strips',
    Mrp : 5,
    Qty : 5,
    Vat : 5.5
},
{
    Productcode : '8941651',
    ProductName : 'CIPLACTIN',
    strght : '2mg',
    BatchNo : '65446',
    Expdt : 2017-06-01,
    Mfg : 'CIPLA',
    pkg : 'Strips',
    Mrp : 5,
    Qty : 5,
    Vat : 5.5
},
{
    Productcode : '541326',
    ProductName : 'Parlodel',
    strght : '2.5 mg',
    BatchNo : '65446',
    Expdt : 2017-06-01,
    Mfg : 'Ranbaxy',
    pkg : 'Strips',
    Mrp : 5,
    Qty : 5,
    Vat : 5.5
},
{
    Productcode : '8945123',
    ProductName : 'Parlodel',
    strght : '5 mg',
    BatchNo : '65446',
    Expdt : 2017-06-01,
    Mfg : 'Ranbaxy',
    pkg : 'Strips',
    Mrp : 5,
    Qty : 5,
    Vat : 5.5
}]

login.stock.create(stock,function(req,res){
    res.send('success');
})

});


}