var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var productschema = new Schema({
    systemId : Number,
    productcode : String,
    ProductName : String,
    strength : String,
    ProductCategory : String,
    formulary : String, 
    Manufacturer : String
});

var inventoryschema = new Schema({
    systemid : Number,
    ProductCode : String,
    Qty : Number,
    Uom : String,
    //packingsize : String,
    Batch : Number,
    mfgdt : Date,
    Expirydt : Date,
    Rate : Number,
    Mrp : Number,
    Tax : Number
});

var stockschema = new Schema({
    Productcode : String,
    ProductName : String,
    strght:String,
    BatchNo : String,
    Expdt : Date,
    Mfg : String,
    pkg : String,
    Mrp : Number,
    Qty : Number,
    Vat : Number
});

var loginschema = new Schema({
    username : String,
    password : String
});

var product = mongoose.model('product',productschema);
var inventory = mongoose.model('inventory',inventoryschema);
var login = mongoose.model('login',loginschema);
var stock = mongoose.model('stock', stockschema);

module.exports = {
    product : product,
    inventory : inventory,
    login : login,
    stock : stock

}