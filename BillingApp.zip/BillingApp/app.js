
var express = require('express');
var app = express();


var mongoose = require('mongoose');
var config = require('./config');
var ejs = require('ejs');



app.use('/assets', express.static(__dirname + '/public'));
app.set('view engine', 'ejs');

mongoose.connect(config.getDbConnectionString());

require('./router/router')(app);



var port = process.env.PORT || 8080;

app.listen(port)
    console.log('Server is Listning on Port : ' + port);


