var datab = require('../models/databasemodel');
//var updater = require('./update');
var bodyparser = require('body-parser')
var urlencodedparser = bodyparser.urlencoded({extended : false})
var token = '';
var session = '';
module.exports = function(app){

    app.get('/getprod',function(req,res){
        datab.product.find(function(err,result){
            res.json(result);
        })
    });

    app.get('/getinv',function(req,res){

        datab.stock.find(function(err,result){
            res.json(result);
        });
    });

    app.get('/',function(req,res){
        session = 'Invalid'
        res.render('index',{ message : token });        
    });


    app.post('/storeperson',urlencodedparser,function(req,res){
        var username = req.body.username;
        var password = req.body.password;

        datab.login.findOne({username : username , password : password}, function(err,user){

        if(err){
            console.log(err);
                return res.status(500).send();
            }

        else if(!user){
            token = 'Invalid Username or Password !'
            res.redirect('/');
            }

        else {
            token = '';
            session = 'Valid'
            res.redirect('/Home')
            }

        });
            
    });


    app.get('/Home', function(req,res){
        if(session === 'Valid'){
                res.render('Home')
        }
        else {
            token = 'Please Login !'
            res.render('index',{message : token})
        }
        
    });

    app.post('/addprod',urlencodedparser,function(req,res){
        
        var pcode = req.body.pcode;
        var pname = req.body.pname;
        var pstrength = req.body.pstrength;
        var pcategory = req.body.pcategory;
        var pformula = req.body.pformula;
        var pmfg = req.body.pmfg;
        var sysid = pcode.substring(1,4)+pcode.length+pname.substring(1,4);

        var prod = {
            systemId : pcode.length*10,
            productcode : pcode,
            ProductName : pname,
            strength : pstrength,
            ProductCategory : pcategory,
            formulary : pformula, 
            Manufacturer : pmfg
        }

        datab.product.create(prod,function(err,result){

            res.send(prod);

        })
    })

    app.post('/updateinv',urlencodedparser,function(req,res){
        
        var inv ={ 
        prodcode : req.body.prodcode,
        qty : req.body.qty,
        uom : req.body.uom,
        batch : req.body.batch,
        mfgdt : req.body.mfgdt,
        expdt : req.body.expdt,
        rate : req.body.rate,
        mrp : req.body.mrp,
        tax : req.body.tax
    }
    console.log(inv)
     for(var i=0;i<inv.prodcode.length;i++){
         var x = {
         systemid : '',
         ProductCode : inv.prodcode[i],
         Qty : inv.qty[i],
         Uom : inv.uom[i],
         Batch : inv.batch[i],
         mfgdt : inv.mfgdt[i],
         Expirydt : inv.expdt[i],
         Rate : inv.rate[i],
         Mrp : inv.mrp[i],
         Tax : inv.tax[i]
         }

         datab.inventory.create(x,function(err,result){
             if(err){
                 console.log(err);
             }
        })


        res.send('Success',inv)

     }
    });

}