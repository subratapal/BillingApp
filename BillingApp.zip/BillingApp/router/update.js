
/*var datab = require('../models/databasemodel');

var c1 = 0; var c2 = 0; var p1; var p2;

v = datab.inventory.find(function(err,count){
    console.log(count)
});
console
datab.stock.count({}, function(err,count){
    c2 = count;
   
});

console.log(c1);
//console.log(c2);


if (c2 != c1) {
    
    datab.product.find(function(err,result){
        var p1 = result;
        console.log(p1)
    })

}
*/

