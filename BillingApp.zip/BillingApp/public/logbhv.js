



function loadp(){
    var x = document.getElementById('billcust');
    var y = document.getElementById('addprod');
    var z = document.getElementById('updateinv')
        y.style.display = 'none';
        z.style.display = 'none';
}

function billc() {
    var x = document.getElementById('billcust');
    var y = document.getElementById('addprod');
    var z = document.getElementById('updateinv')
        y.style.display = 'none'
        z.style.display = 'none'
        x.style.display = 'block'
}

function addp() {
    var x = document.getElementById('billcust');
    var y = document.getElementById('addprod');
    var z = document.getElementById('updateinv')
        x.style.display = 'none'
        z.style.display = 'none'
        y.style.display = 'block'
}

function updinv() {
    var x = document.getElementById('billcust');
    var y = document.getElementById('addprod');
    var z = document.getElementById('updateinv')
        y.style.display = 'none'
        x.style.display = 'none'
        z.style.display = 'block'
        
    
}

n =  new Date();
y = n.getFullYear();
m = n.getMonth() + 1;
d = n.getDate();
document.getElementById("demo").innerHTML = m + "/" + d + "/" + y;
