var myapp = angular.module('myapp', []);

myapp.controller('invnctrl',function($scope, $http) {
    $http.get('/getprod').then(function(response){
        $scope.prods = response.data;
    });
});

myapp.controller('getinventory',function($scope,$http) {
    $http.get('/getinv').then(function(response){
        console.log(JSON.stringify(response.data));
        $scope.inv = response.data;
    })



})

myapp.controller('Total', function($scope){
    $scope.qty
    $scope.Mrp
})

/*app.controller('invctrl', function($scope, $http) {
$http.get('/getprod')
$scope.items = Response.data;
$scope.selectedItem = $scope.items[1]
});*/